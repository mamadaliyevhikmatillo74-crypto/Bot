from keep_alive import keep_alive

print("Ishga tushyapti...")
keep_alive()