from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
)
from locales import LANG_TEXTS, LANG_CHOICES, LANG_CODES

BOT_TOKEN = "BOT_TOKENINGIZNI_BU_YERGA_YOZING"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        LANG_TEXTS["uz"]["welcome"],
        reply_markup=ReplyKeyboardMarkup(LANG_CHOICES, resize_keyboard=True)
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text

    if text in LANG_CODES:
        lang = LANG_CODES[text]
        context.user_data["lang"] = lang
        await update.message.reply_text(
            LANG_TEXTS[lang]["language_selected"],
            reply_markup=ReplyKeyboardMarkup(LANG_TEXTS[lang]["menu"], resize_keyboard=True)
        )
        return

    lang = context.user_data.get("lang", "uz")
    if text in sum(LANG_TEXTS[lang]["menu"], []):
        if text.startswith("📦"):
            await update.message.reply_text(LANG_TEXTS[lang]["products"])
        elif text.startswith("📞"):
            await update.message.reply_text(LANG_TEXTS[lang]["contact"])
        elif text.startswith("ℹ️"):
            await update.message.reply_text(LANG_TEXTS[lang]["about"])
        elif text.startswith("⚙️"):
            await update.message.reply_text(LANG_TEXTS[lang]["settings"])
    else:
        await update.message.reply_text("Iltimos, menyudagi tugmalardan foydalaning.")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT, handle_message))
app.run_polling()