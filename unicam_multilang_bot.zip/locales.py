LANG_TEXTS = {
    "uz": {
        "language": "🇺🇿 O'zbek",
        "welcome": "Assalomu alaykum! Tilni tanlang:",
        "language_selected": "Siz O'zbek tilini tanladingiz.",
        "menu": [["📦 Mahsulotlar", "📞 Bog'lanish"], ["ℹ️ Bot haqida", "⚙️ Sozlamalar"]],
        "products": "Mahsulotlar roʻyxati...",
        "contact": "Bogʻlanish uchun: +998 90 123 45 67",
        "about": "Bu Unicam brendining rasmiy Telegram boti.",
        "settings": "Sozlamalar bo‘limi mavjud emas.",
    },
    "ru": {
        "language": "🇷🇺 Русский",
        "welcome": "Здравствуйте! Выберите язык:",
        "language_selected": "Вы выбрали русский язык.",
        "menu": [["📦 Продукты", "📞 Контакт"], ["ℹ️ О боте", "⚙️ Настройки"]],
        "products": "Список продуктов...",
        "contact": "Связаться: +998 90 123 45 67",
        "about": "Это официальный Telegram-бот бренда Unicam.",
        "settings": "Раздел настроек пока недоступен.",
    },
    "en": {
        "language": "🇬🇧 English",
        "welcome": "Hello! Please choose a language:",
        "language_selected": "You selected English.",
        "menu": [["📦 Products", "📞 Contact"], ["ℹ️ About bot", "⚙️ Settings"]],
        "products": "List of products...",
        "contact": "Contact: +998 90 123 45 67",
        "about": "This is the official Telegram bot of Unicam brand.",
        "settings": "Settings section is not available yet.",
    },
}

LANG_CHOICES = [
    ["🇺🇿 O'zbek", "🇷🇺 Русский", "🇬🇧 English"]
]

LANG_CODES = {
    "🇺🇿 O'zbek": "uz",
    "🇷🇺 Русский": "ru",
    "🇬🇧 English": "en"
}