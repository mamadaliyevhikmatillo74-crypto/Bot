from keep_alive import keep_alive
from bot import main

if __name__ == "__main__":
    keep_alive()
    main()
